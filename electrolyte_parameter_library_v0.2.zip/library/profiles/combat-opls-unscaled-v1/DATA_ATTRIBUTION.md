# ComBat data attribution

Source: Rasha Atwi and collaborators, ComBat Database, https://github.com/rashatwi/combat
Upstream commit: caa1130df2b4feeb9eaafe1565af8e1a4283986a

The upstream README Licensing section declares the database CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . The repository also includes an MIT LICENSE file, retained as LICENSE.ComBat. The database declaration must not be replaced by a blanket MIT label.

Changes made here: convert LAMMPS real-unit molecular base parameters to GROMACS/OpenMM units and explicit topology; namespace atom types; preserve unscaled base charges; add provenance, integrity and energy equivalence records. The upstream composition-dependent charge-screening workflow has not been reproduced. No experimental validation is claimed.
