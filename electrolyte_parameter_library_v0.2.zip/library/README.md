# 电解液组分与力场参数库 v0.2

本库已保存实际数值参数和分子坐标，可直接供本项目建模使用。**当前是有来源、经过结构/软件检查的候选库；尚未完成密度、输运和溶剂化性质的实验验证。**“统一”指每个 profile 内统一规则，不能跨 profile 混用。

## 覆盖情况

- 组分目录：23 种溶剂、10 种中性添加剂、10 种阴离子、Li⁺，共 44 个分子/离子身份；另有 10 种锂盐配方单元。
- 38 个组分有实际数值参数，跨两个 profile 共 52 个参数包。
- GAFF2 profile：38 包，即 23 溶剂、8 添加剂、6 阴离子与一个明确标注迁移限制的 Li⁺候选。
- OPLS profile：14 包；来自 ComBat，含 Li⁺、TFSI⁻、DOL 和 11 个常见溶剂。
- 完整锂盐：LiPF6、LiFSI、LiTFSI、LiPO2F2、LiOTf、LiNO3。锂盐复用 Li⁺，阴离子按化学计量展开。
- 缺口：BF4⁻、BOB⁻、DFOB⁻、ClO4⁻、TMSP、TMSB。已经保留结构、生成失败记录和日志；它们不能用于当前库的生产建模。

逐项列表见 `inventory.csv`；完整来源、profile 路径与状态见 `inventory.json`。

| 类别 | 已有数值参数的组分 |
|---|---|
| 碳酸酯溶剂 | EC、PC、DMC、EMC、DEC |
| 醚类溶剂 | DME、DEE、G2、G3、G4、DOL、THF、2MeTHF |
| 其他溶剂 | ACN、MA、EA、MP、EP、GBL、SL、DMSO、TMP、TEP |
| 中性添加剂 | FEC、VC、VEC、PS、DTD、ES、SN、ADN |
| 阴离子 | PF6、FSI、TFSI、PO2F2、OTf、NO3 |
| 阳离子 | Li⁺，按 profile 使用对应模型 |

组分身份含 canonical SMILES、分子式、RDKit 平均摩尔质量和初始 3D 结构。构型不是量化优化结果；手性未明确的 PC/FEC/VEC 等没有保证构成真实的外消旋比例。身份目录不等于参数目录。

## Profile 1：GAFF2/AM1-BCC 完整电荷候选

路径：`profiles/gaff2-am1bcc-fullcharge-v1/`

- AmberTools 26.0、ACPYPE 2023.10.27；确切 GAFF 数据版本/哈希记录于 `provenance.json`。
- 有机分子与六种可生成阴离子实际完成了 GAFF2/AM1-BCC 参数化；保留输入、sqm/ACPYPE 日志、frcmod、AMBER 与 GROMACS 中间文件。
- Lorentz–Berthelot 混合规则：GROMACS comb-rule=2；1–4 LJ=0.5、Coulomb=1/1.2；电荷不缩放。
- Li⁺独立取自 OpenMM/AmberTools 的 Joung–Cheatham TIP3P 模型。来源 DOI：10.1021/jp8001614，原 XML 与哈希保留。
- **Li⁺模型原本针对 TIP3P 水，迁移到碳酸酯/醚没有在本项目验证。GAFF2 字段在这里表示装配规则，不能解释为 Li⁺由 GAFF2 参数化。**
- 高价态无机阴离子即使生成成功，也只通过结构、电荷与有限能量检查，没有证明 AM1-BCC/GAFF2 适用于该化学环境。PF6/FSI 等优先级应是论文参数和实验标定。
- TMSP 不接受用硅原子误识别或按碳类比的参数充数；ClO4 发现 ATTN/零值角度缺项，拒绝进入可用库。

此 profile 适合开始流程开发、基线比较和后续验证，不能直接声称可准确预测电导率/黏度。

## Profile 2：ComBat OPLS 未缩放基础参数

路径：`profiles/combat-opls-unscaled-v1/`

来源：[ComBat](https://github.com/rashatwi/combat)，数据库按上游声明为 CC BY 4.0，仓库另有 MIT LICENSE。上游 commit 已固定在每个 metadata.json，许可证已随库保存。

完整 profile 内使用 geometric σ/ε 混合（comb-rule=3），1–4 LJ/Coulomb 均为 0.5。源 LAMMPS real 单位转为 GROMACS 单位，保留谐键、谐角、Fourier 二面角、CVFF improper 与明确 1–4 pairs。

14 个条目包括：G4、SL、THF、G3、DMSO、TEP、MA、ACN、TMP、G2、DME、Li、TFSI、DOL。

每个条目用原始构型和两组扰动构型，逐项比较独立 LAMMPS 公式计算的键/角/二面角/非键能量与 OpenMM 能量，结果见 `energy_equivalence.json`。

**上游混合电解液脚本采用与溶剂相关的电荷缩放。这里保存的是未缩放基础参数，不能把上游已报告的性能直接当作本库的验证结果。**来源论文测试范围也不能外推到任意新配方。

## 直接使用

在项目 `electrolyte_md` 目录运行：

```bash
source .venv312/bin/activate
python recipe_from_catalog.py --name EC_EMC_LiPF6_new --solvents EC:0.30 EMC:0.55 --salts LiPF6:0.15 --box-nm 5.2 5.2 5.2 --total-molecules 1000 --out my_recipes/ec_emc.json
python workflow.py my_recipes/ec_emc.json --workdir runs --library library/profiles/gaff2-am1bcc-fullcharge-v1
```

`recipe_from_catalog.py` 填写 SMILES、摩尔质量和纯度=1.0，用户无需重复填写；实际纯度不为 1 时应编辑 JSON 并显式建模杂质。mass_fraction 为总配方质量分数，包含盐和添加剂。

OPLS DOL/DME/LiTFSI 示例：

```bash
python recipe_from_catalog.py --name DOL_DME_LiTFSI_new --solvents DOL:0.425 DME:0.425 --salts LiTFSI:0.15 --box-nm 5.2 5.2 5.2 --out my_recipes/dol_dme.json
python workflow.py my_recipes/dol_dme.json --workdir runs_opls --library library/profiles/combat-opls-unscaled-v1
```

workflow 自动读取库的 templates/profile.json。分步执行时必须显式传递同一套模板：

```bash
python recipe_generate.py my_recipes/dol_dme.json --workdir runs_opls --templates library/profiles/combat-opls-unscaled-v1/templates
# 在生成的目录中，使用该 profile 的绝对 library 路径调用 prepare_system.py。
```

新分子只能在 GAFF2 profile 中尝试自动参数化；程序会拒绝将 GAFF2 自动结果混入 OPLS profile。缺失的阴离子不会通过猜测数值绕过错误。

## 如何达到“经过验证”

验证对象应当是**整个配方和适用范围**，单分子参数审核不能保证 Li–溶剂、Li–阴离子交叉作用正确。

1. 固定力场版本、混合规则、1–4 缩放、电荷方案和离子模型。保留来源/哈希；不得为了拟合一个结果随意换另一个离子模型。
2. 检查每个分子的身份、连接、原子序、电荷、质量、参数缺项、构象势能和参数转换。库已完成结构检查；ComBat 还做了能量等价检查。
3. 验证纯溶剂液态密度，并进一步比较黏度、扩散和介电响应。必须核对实验温度、压力、纯度与相态；EC 在室温附近的相态尤其需核对。
4. 选择盐浓度/温度/溶剂比例的基准矩阵，至少覆盖碳酸酯 LiPF6、醚 LiTFSI/LiFSI、目标添加剂配方。比较密度、溶剂化、扩散、电导率与黏度，检查离子聚集是否异常。
5. 每个条件至少三个独立种子，做平衡判断、采样长度/盒尺寸收敛和分块误差；拟合窗口不能靠挑选来凑实验值。
6. 将校准配方与测试配方分开。报告通过/失败、误差和浓度/温度适用区间；仅此后才把相应 profile/配方范围标为物理验证通过。

已生成 23 个纯溶剂、69 份独立种子验证配方，位于 `validation/physical/gaff2-am1bcc-fullcharge-v1`。默认每份 0.1 ns NVT + 5 ns NPT + 20 ns NVT；这是初始采样方案，不能承诺收敛。没有自动启动这批长程作业。

可重建或选择子集：

```bash
python plan_validation.py --profile gaff2-am1bcc-fullcharge-v1 --names DME TMP --replicas 3
```

有部分纯溶剂密度/温度候选参考来自 ComBat data.csv，保留为 `source_verification_pending`。尚未找到或核实原始实验引用的点不作为合格判据。无参考的组分使用 1 g/cm³ 初始密度和 298.15 K 作为建模占位值，不能把这些值当作实验目标。

## 本次检查与复现

- 52 包全部通过身份、显式连接、原子顺序、电荷、质量、哈希完整性检查。
- 37 个自动生成包完成 OpenMM 单分子有限能量检查；Li⁺是单原子来源参数。
- 14 个 ComBat 包通过三构型逐项能量等价检查。
- EC/EMC/LiPF6 与 DOL/DME/LiTFSI 的两套真实组分短程建模/MD/分析流程通过，输出位于 `validation/smoke/`。前两套生产段仅 0.2 ps；另有纯 DME 0.05 ps 流程检查通过。结果不能用于性质预测或验证。
- 溶剂/混合体系实验一致性：**尚未验证**。

```bash
python library_audit.py
python -m unittest discover -s tests -v
```

重建 GAFF2 参数需要 AmberTools/ACPYPE（本次安装在项目 .amber）：

```bash
PATH="$PWD/.amber/bin:$PATH" AMBERHOME="$PWD/.amber" OMP_NUM_THREADS=1 python build_library.py --jobs 3
```

新增参数不能只改状态字符串，应保留对应验证证据、参考来源和适用条件。
