import copy
import math
import re
from collections import Counter

NA = 6.02214076e23


def number(value, label, low=0, high=None, strict=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f'{label}: expected finite number')
    if (value <= low if strict else value < low) or (high is not None and value > high):
        raise ValueError(f'{label}: out of range')
    return value


def integer(value, label, low=1):
    number(value, label, low)
    if int(value) != value:
        raise ValueError(f'{label}: expected integer')
    return int(value)


def safe_name(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}', value):
        raise ValueError('name must be 1..64 ASCII letters, digits, _ or -, starting with letter/digit')
    return value


def validate(recipe):
    r = copy.deepcopy(recipe)
    safe_name(r['recipe_name'])
    if not isinstance(r.get('time'), str) or not r['time'].strip():
        raise ValueError('time is required (ISO-8601 string recommended)')
    components = []
    names = set()
    for group in ('solvents', 'additives', 'salts'):
        if not isinstance(r.get(group), list):
            raise ValueError(f'{group}: expected list (empty allowed)')
        for item in r[group]:
            for field in ('name', 'full_name', 'smiles', 'mass_fraction', 'molar_mass', 'purity'):
                if field not in item:
                    raise ValueError(f'{group}: missing {field}')
            safe_name(item['name'])
            if item['name'] in names:
                raise ValueError('duplicate component name')
            names.add(item['name'])
            for field in ('full_name', 'smiles'):
                if not isinstance(item[field], str) or not item[field].strip():
                    raise ValueError(f'{field}: expected nonempty string')
            number(item['mass_fraction'], 'mass_fraction', 0, 1)
            number(item['purity'], 'purity', 0, 1)
            number(item['molar_mass'], 'molar_mass', strict=True)
            components.append((group, item))
    if not components or not math.isclose(sum(i['mass_fraction'] for _, i in components), 1, abs_tol=1e-6):
        raise ValueError('mass fractions must sum to 1 within 1e-6')
    s = r['simulation']
    if any(key in s for key in ('concentration', 'target_concentration', 'concentration_mol_L')):
        raise ValueError('independent target concentration is not supported; derive from counts/box')
    if s.get('units') != {'temperature': 'K', 'pressure': 'bar', 'concentration': 'mol/L', 'box': 'nm'}:
        raise ValueError('units must be K, bar, mol/L and nm')
    number(s['temperature'], 'temperature', strict=True)
    number(s['pressure'], 'pressure', strict=True)
    s['total_molecules'] = integer(s['total_molecules'], 'total_molecules')
    box = s['box_nm']
    if not isinstance(box, list) or len(box) != 3:
        raise ValueError('box_nm must contain 3 orthorhombic lengths')
    for v in box:
        number(v, 'box_nm', strict=True)
    defaults = {'timestep_fs': 1, 'cutoff_nm': 1, 'nvt_steps': 10000, 'npt_steps': 100000,
                'production_steps': 1000000, 'report_interval': 1000, 'seed': 2026,
                'friction_per_ps': 1, 'platform': 'CPU'}
    for key, value in defaults.items():
        s.setdefault(key, value)
    for key in ('nvt_steps', 'npt_steps', 'production_steps', 'report_interval', 'seed'):
        s[key] = integer(s[key], key)
    if s['report_interval'] > s['production_steps']:
        raise ValueError('report_interval exceeds production_steps')
    for key in ('timestep_fs', 'cutoff_nm', 'friction_per_ps'):
        number(s[key], key, strict=True)
    if min(box) <= 2 * s['cutoff_nm']:
        raise ValueError('box length must exceed twice nonbonded cutoff')
    r.setdefault('purity_policy', 'reject')
    if r['purity_policy'] not in ('reject', 'active_renormalize'):
        raise ValueError('purity_policy must be reject or active_renormalize')
    if r['purity_policy'] == 'reject' and any(i['purity'] < 1 and i['mass_fraction'] > 0 for _, i in components):
        raise ValueError('impure input: specify impurities explicitly or choose active_renormalize')
    return r


def split_smiles(smiles, salt=False):
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f'invalid SMILES: {smiles}')
    fragments = Chem.GetMolFrags(mol, asMols=True, sanitizeFrags=True)
    parts = [(Chem.MolToSmiles(m), sum(a.GetFormalCharge() for a in m.GetAtoms())) for m in fragments]
    if salt:
        if sum(q for _, q in parts) != 0 or not any(q > 0 for _, q in parts) or not any(q < 0 for _, q in parts):
            raise ValueError('salt must contain charge-balanced positive and negative fragments')
        if any(q == 0 for _, q in parts):
            raise ValueError('neutral salt fragment: model solvates separately')
    elif len(parts) != 1 or parts[0][1] != 0:
        raise ValueError('solvent/additive must be a single neutral molecule')
    return parts


def allocate(weights, target):
    """Formula-unit rounding; salt fragments inherit the same count."""
    raw = [target * w / sum(weights) for w in weights]
    result = [int(v) for v in raw]
    for i in sorted(range(len(raw)), key=lambda j: (-(raw[j] - result[j]), j))[:target - sum(result)]:
        result[i] += 1
    return result


def build_manifest(recipe, splitter=split_smiles):
    r = validate(recipe)
    items = [(g, i) for g in ('solvents', 'additives', 'salts') for i in r[g]]
    weights = [i['mass_fraction'] * i['purity'] / i['molar_mass'] for _, i in items]
    if sum(weights) == 0:
        raise ValueError('no active material')
    counts = allocate(weights, r['simulation']['total_molecules'])
    species, by_smiles, rows = [], {}, []
    for (group, item), count, weight in zip(items, counts, weights):
        if weight > 0 and count == 0:
            raise ValueError(f"{item['name']} rounded to zero: increase total_molecules")
        parts = splitter(item['smiles'], salt=group == 'salts')
        ids = []
        for smiles, charge in parts:
            if smiles not in by_smiles:
                sid = f'S{len(species):02d}'
                by_smiles[smiles] = sid
                species.append({'id': sid, 'smiles': smiles, 'formal_charge': charge, 'count': 0,
                                'role': 'cation' if charge > 0 else 'anion' if charge < 0 else 'neutral',
                                'aliases': []})
            sid = by_smiles[smiles]
            sp = next(p for p in species if p['id'] == sid)
            sp['count'] += count
            alias = item['name'] + ('_cation' if charge > 0 else '_anion' if charge < 0 else '')
            if alias not in sp['aliases']:
                sp['aliases'].append(alias)
            ids.append(sid)
        rows.append({'name': item['name'], 'group': group, 'formula_units': count, 'species': ids,
                     'moles_per_gram_input': weight})
    if sum(p['formal_charge'] * p['count'] for p in species) != 0:
        raise ValueError('discrete system is not electroneutral')
    volume_l = math.prod(r['simulation']['box_nm']) * 1e-24
    mass_g = sum(n * i['molar_mass'] / NA for (_, i), n in zip(items, counts))
    for row in rows:
        row['realized_concentration_mol_L'] = row['formula_units'] / NA / volume_l
    return {'schema_version': 1, 'recipe': r, 'species': species, 'components': rows,
            'anchor': 'total formula units BEFORE salt splitting',
            'particle_molecule_count': sum(p['count'] for p in species),
            'initial_density_g_cm3': mass_g / (volume_l * 1000),
            'warnings': ['Initial box fixes initial density; NPT changes volume and concentration.',
                         'Active renormalization omits unspecified impurities.' ] if r['purity_policy'] == 'active_renormalize'
                        else ['Initial box fixes initial density; NPT changes volume and concentration.']}
