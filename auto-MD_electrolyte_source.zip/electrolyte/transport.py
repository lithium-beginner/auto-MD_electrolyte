"""SI conversions and time-origin-averaged Einstein/Green-Kubo estimators."""
KB = 1.380649e-23
E = 1.602176634e-19


def unwrap_com(positions, box):
    import numpy as np
    delta = np.diff(positions, axis=0)
    delta -= box * np.round(delta / box)
    return np.concatenate([positions[:1], positions[:1] + np.cumsum(delta, axis=0)], axis=0)


def einstein_curves(com_A, charges, dt_ps, max_lag_fraction=0.5):
    import numpy as np
    if not 0 < max_lag_fraction <= 0.5:
        raise ValueError('max_lag_fraction must be in (0, 0.5]')
    if dt_ps <= 0:
        raise ValueError('frame interval must be positive')
    n = len(com_A)
    maxlag = int((n - 1) * max_lag_fraction)
    if maxlag < 3:
        raise ValueError('trajectory too short for transport analysis')
    lags = np.arange(1, maxlag + 1)
    msd = np.empty((len(lags), com_A.shape[1]))
    collective = np.empty(len(lags))
    origins = n - lags
    for i, lag in enumerate(lags):
        displacement = (com_A[lag:] - com_A[:-lag]) * 1e-10
        msd[i] = np.mean(np.sum(displacement ** 2, axis=-1), axis=0)
        total = np.einsum('tmx,m->tx', displacement, charges)
        collective[i] = np.mean(np.sum(total ** 2, axis=-1))
    return lags * dt_ps * 1e-12, msd, collective, origins


def fit_slope(time, curve, fractions):
    import numpy as np
    a, b = fractions
    if not 0 <= a < b <= 1:
        raise ValueError('fit_fraction must satisfy 0 <= start < end <= 1')
    start, stop = int(a * len(time)), int(b * len(time))
    if stop - start < 3:
        raise ValueError('need at least three lag points in fit window')
    x, y = time[start:stop], curve[start:stop]
    slope, intercept = np.polyfit(x, y, 1)
    residual = np.sum((y - (slope * x + intercept)) ** 2)
    variance = np.sum((y - np.mean(y)) ** 2)
    return float(slope), float(1 - residual / variance) if variance else None


def viscosity(stress_bar, dt_ps, volume_nm3, temperature):
    """Off-diagonal Pxy/Pxz/Pyz, stationary NVT stress; running integral in Pa s."""
    import numpy as np
    x = np.asarray(stress_bar) * 1e5
    if x.ndim != 2 or x.shape[1] != 3 or len(x) < 8 or not np.all(np.isfinite(x)):
        raise ValueError('stress must be finite N x 3 with at least 8 samples')
    x -= x.mean(axis=0)
    acf = np.array([np.mean(x[:len(x)-lag] * x[lag:]) for lag in range(len(x) // 2)])
    integral = np.concatenate([[0], np.cumsum((acf[1:] + acf[:-1]) * 0.5 * dt_ps * 1e-12)])
    return np.arange(len(acf)) * dt_ps, acf, integral * volume_nm3 * 1e-27 / (KB * temperature)
