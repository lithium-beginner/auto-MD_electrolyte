"""Parameter normalization and explicit provenance validation.

Curated entries: <library>/<sha256(canonical SMILES)[:16]>/metadata.json,
 molecule.itp, atomtypes.atp and molecule.pdb. ATP here is an include containing
 a GROMACS [atomtypes] section, not GROMACS's optional name/mass-only .atp table.
"""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess


def key(smiles):
    return hashlib.sha256(smiles.encode()).hexdigest()[:16]


def sections(text):
    current = None
    result = {}
    for line in text.splitlines():
        raw = line.split(';')[0].strip()
        if not raw:
            continue
        if raw.startswith('#'):
            raise ValueError('parameter includes/preprocessor directives must be flattened first')
        match = re.fullmatch(r'\[\s*(\w+)\s*\]', raw)
        if match:
            current = match[1]
            result.setdefault(current, [])
        elif current:
            result[current].append(raw.split())
    return result


def validate_bundle(folder, sp, expected_forcefield="GAFF2"):
    meta = json.loads((folder / 'metadata.json').read_text())
    if meta.get('smiles') != sp['smiles'] or meta.get('forcefield') != expected_forcefield:
        raise ValueError('parameter SMILES/forcefield mismatch')
    if not meta.get('source'):
        raise ValueError('parameter source is required')
    blocks = sections((folder / 'molecule.itp').read_text())
    atoms = blocks.get('atoms', [])
    if not atoms or len(blocks.get('moleculetype', [])) != 1:
        raise ValueError('expected one molecule type and nonempty atoms')
    if any(int(a[0]) != i + 1 for i, a in enumerate(atoms)):
        raise ValueError('atom indices must be contiguous')
    charge = sum(float(a[6]) for a in atoms)
    if abs(charge - sp['formal_charge']) > 1e-4:
        raise ValueError(f'partial charge sum {charge} disagrees with formal charge')
    from rdkit import Chem
    mol = Chem.AddHs(Chem.MolFromSmiles(sp['smiles']))
    pdb = Chem.MolFromPDBFile(str(folder / 'molecule.pdb'), removeHs=False, sanitize=False)
    if pdb is None or pdb.GetNumAtoms() != len(atoms) or len(atoms) != mol.GetNumAtoms():
        raise ValueError('SMILES/PDB/topology atom counts disagree')
    pdb_lines = [l for l in (folder / 'molecule.pdb').read_text().splitlines() if l.startswith(('ATOM  ', 'HETATM'))]
    if [l[12:16].strip() for l in pdb_lines] != [a[4] for a in atoms]:
        raise ValueError('PDB atom order/names must exactly match topology')
    from collections import Counter
    if Counter(a.GetSymbol() for a in pdb.GetAtoms()) != Counter(a.GetSymbol() for a in mol.GetAtoms()):
        raise ValueError('PDB elements do not match SMILES')
    return blocks


def normalize_itp(text, sid):
    blocks = sections(text)
    if 'defaults' in blocks:
        raise ValueError('molecule ITP must not contain defaults')
    types = blocks.pop('atomtypes', [])
    prefix = sid + '_'
    mapping = {row[0]: prefix + row[0] for row in types}
    for row in types:
        row[0] = mapping[row[0]]
        # A separate bonded-type column, when present, follows the atom-type.
        if len(row) >= 8 and not row[1].lstrip('-').isdigit():
            row[1] = prefix + row[1]
    for row in blocks.get('atoms', []):
        row[1] = mapping.get(row[1], row[1])
        row[3] = sid
    blocks['moleculetype'][0][0] = sid
    def render(data):
        return '\n'.join('[ ' + name + ' ]\n' + '\n'.join(' '.join(r) for r in rows) for name, rows in data.items()) + '\n'
    return render(blocks), render({'atomtypes': types}) if types else ''


def parameterize(sp, folder, library=None, automatic=False, expected_forcefield="GAFF2"):
    folder.mkdir(parents=True, exist_ok=False)
    source = Path(library) / key(sp['smiles']) if library else None
    if source and source.is_dir():
        for name in ('metadata.json', 'molecule.itp', 'atomtypes.atp', 'molecule.pdb'):
            shutil.copy2(source / name, folder / name)
    else:
        if expected_forcefield != 'GAFF2':
            raise ValueError('automatic GAFF2 parameterization cannot be mixed into this forcefield profile')
        from rdkit import Chem
        from rdkit.Chem import AllChem
        mol = Chem.AddHs(Chem.MolFromSmiles(sp['smiles']))
        if not automatic or mol.GetNumAtoms() == 1:
            raise ValueError(f"missing verified parameters for {sp['aliases']} ({key(sp['smiles'])}); single-atom ions require library entries")
        if shutil.which('acpype') is None:
            raise RuntimeError('acpype executable missing')
        if AllChem.EmbedMolecule(mol, randomSeed=2026) < 0:
            raise ValueError('3D embedding failed')
        if AllChem.MMFFHasAllMoleculeParams(mol):
            AllChem.MMFFOptimizeMolecule(mol)
        Chem.MolToMolFile(mol, str(folder / 'input.mol'))
        command = ['acpype', '-i', 'input.mol', '-b', sp['id'], '-a', 'gaff2', '-c', 'bcc', '-n', str(sp['formal_charge'])]
        with (folder / 'acpype.log').open('w') as log:
            subprocess.run(command, cwd=folder, stdout=log, stderr=subprocess.STDOUT, check=True)
        acdir = folder / (sp['id'] + '.acpype')
        original = (acdir / (sp['id'] + '_GMX.itp')).read_text()
        # Generated posre includes are optional and irrelevant to the unrestrained model.
        original = re.sub(r'#ifdef POSRES.*?#endif', '', original, flags=re.S)
        (folder / 'molecule.itp').write_text(original)
        # Atom order comes from ACPYPE's GRO, never from the RDKit input.
        from openmm.app import GromacsGroFile, PDBFile
        from openmm import Vec3, unit
        from openmm.app import GromacsTopFile
        local_top = folder / 'convert.top'
        local_top.write_text('[ defaults ]\n1 2 yes 0.5 0.8333333333333333\n#include "molecule.itp"\n[ system ]\nconversion\n[ molecules ]\n' + sections(original)['moleculetype'][0][0] + ' 1\n')
        gro = GromacsGroFile(str(acdir / (sp['id'] + '_GMX.gro')))
        top = GromacsTopFile(str(local_top), periodicBoxVectors=(Vec3(5, 0, 0), Vec3(0, 5, 0), Vec3(0, 0, 5)) * unit.nanometer)
        with (folder / 'molecule.pdb').open('w') as f:
            PDBFile.writeFile(top.topology, gro.positions, f)
        (folder / 'atomtypes.atp').write_text('; atomtypes extracted from molecule.itp at assembly\n')
        (folder / 'metadata.json').write_text(json.dumps({'smiles': sp['smiles'], 'forcefield': 'GAFF2',
                 'source': 'ACPYPE + AmberTools antechamber GAFF2/AM1-BCC', 'command': command,
                 'status': 'automatic parameters; requires scientific validation'}, indent=2))
    validate_bundle(folder, sp, expected_forcefield)
    itp, embedded_types = normalize_itp((folder / 'molecule.itp').read_text(), sp['id'])
    external_types = (folder / 'atomtypes.atp').read_text()
    if embedded_types and sections(external_types).get('atomtypes'):
        raise ValueError('duplicate embedded and external atomtypes')
    (folder / 'molecule.itp').write_text(itp)
    if embedded_types:
        (folder / 'atomtypes.atp').write_text(embedded_types)
    # OpenMM cannot infer Li/Ar reliably from names without atomic numbers.
    from rdkit import Chem
    pdbmol = Chem.MolFromPDBFile(str(folder / 'molecule.pdb'), removeHs=False, sanitize=False)
    atom_rows = sections(itp)['atoms']
    numbers = {}
    for row, atom in zip(atom_rows, pdbmol.GetAtoms()):
        z = atom.GetAtomicNum()
        if row[1] in numbers and numbers[row[1]] != z:
            raise ValueError('one atomtype assigned to multiple elements')
        numbers[row[1]] = z
    type_rows = sections((folder / 'atomtypes.atp').read_text()).get('atomtypes', [])
    for row in type_rows:
        if row[0] not in numbers:
            continue
        z = numbers[row[0]]
        if len(row) == 6:
            row[1:1] = [row[0], str(z)]
        elif len(row) == 7 and row[1][0].isalpha():
            row.insert(2, str(z))
        elif len(row) in (7, 8):
            given = int(row[1] if len(row) == 7 else row[2])
            if given != z:
                raise ValueError('atomtype atomic number disagrees with PDB')
            if len(row) == 7:
                row.insert(1, row[0])
        else:
            raise ValueError('unsupported atomtype layout')
    for row in type_rows:
        if row[0] in numbers:
            row[3] = format(float(row[3]), '.8f')
    if type_rows:
        (folder / 'atomtypes.atp').write_text('[ atomtypes ]\n' + '\n'.join(' '.join(r) for r in type_rows) + '\n')
    # Namespace each residue consistently for analysis. Keep atom names/order.
    lines = (folder / 'molecule.pdb').read_text().splitlines()
    lines = [l[:17] + f"{sp['id']:>3}" + l[20:] if l.startswith(('ATOM  ', 'HETATM')) else l for l in lines]
    (folder / 'molecule.pdb').write_text('\n'.join(lines) + '\n')
