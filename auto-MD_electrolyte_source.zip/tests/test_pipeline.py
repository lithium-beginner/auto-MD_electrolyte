"""Integration fixture uses deliberately arbitrary LJ parameters, NOT electrolyte data."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from electrolyte.parameters import key

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(shutil.which('packmol'), 'Packmol executable required')
class PipelineTests(unittest.TestCase):
    def test_toy_ionic_pipeline(self):
        from rdkit import Chem
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            library = tmp / 'library'
            molecules = [('AR', '[Ar]', 'Ar', 39.948, 0, .5), ('LI', '[Li+]', 'Li', 6.94, 1, None),
                         ('CL', '[Cl-]', 'Cl', 35.45, -1, None)]
            for name, smiles, element, mass, charge, _ in molecules:
                canonical = Chem.MolToSmiles(Chem.MolFromSmiles(smiles))
                folder = library / key(canonical)
                folder.mkdir(parents=True)
                mol = Chem.MolFromSmiles(smiles)
                conf = Chem.Conformer(1)
                conf.SetAtomPosition(0, (0, 0, 0))
                mol.AddConformer(conf)
                Chem.MolToPDBFile(mol, str(folder / 'molecule.pdb'))
                line = next(l for l in (folder / 'molecule.pdb').read_text().splitlines() if l.startswith('HETATM'))
                atom_name = line[12:16].strip()
                (folder / 'molecule.itp').write_text(f'[ moleculetype ]\n{name} 3\n[ atoms ]\n1 {name} 1 {name} {atom_name} 1 {charge} {mass}\n')
                (folder / 'atomtypes.atp').write_text(f'[ atomtypes ]\n{name} {mass} 0 A 0.3 0.1\n')
                (folder / 'metadata.json').write_text(json.dumps({'smiles': canonical, 'forcefield': 'GAFF2',
                      'source': 'SOFTWARE TEST ONLY: arbitrary LJ, never use for physical conclusions'}))
            component = lambda name, smiles, fraction, mass: {'name': name, 'full_name': name, 'smiles': smiles,
                       'mass_fraction': fraction, 'molar_mass': mass, 'purity': 1}
            recipe = {'recipe_name': 'toy', 'time': '2026-10-08',
                      'solvents': [component('AR', '[Ar]', .5, 39.948)], 'additives': [],
                      'salts': [component('LiCl', '[Li+].[Cl-]', .5, 42.39)],
                      'simulation': {'temperature': 300, 'pressure': 1, 'total_molecules': 12,
                      'box_nm': [3, 3, 3], 'units': {'temperature': 'K', 'pressure': 'bar', 'concentration': 'mol/L', 'box': 'nm'},
                      'nvt_steps': 10, 'npt_steps': 10, 'production_steps': 100, 'report_interval': 2,
                      'platform': 'Reference'}}
            source = tmp / 'input.json'
            source.write_text(json.dumps(recipe))
            def run(script, *args, cwd=ROOT):
                result = subprocess.run([sys.executable, str(script), *map(str, args)], cwd=cwd, capture_output=True, text=True)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            run(ROOT / 'recipe_generate.py', source, '--workdir', tmp / 'work')
            work = tmp / 'work/toy'
            config = json.loads((work / 'templates/analysis.json').read_text())
            config.update(donor_selection='element Cl', anion_selection='element Cl')
            (work / 'templates/analysis.json').write_text(json.dumps(config))
            run(work / 'prepare_system.py', '--library', library, cwd=work)
            run(work / 'run_md.py', cwd=work)
            run(work / 'analyze.py', cwd=work)
            summary = json.loads((work / 'results/summary.json').read_text())
            self.assertIn('collective_S_m', summary['conductivity'])
            self.assertTrue((work / 'completed.json').is_file())
            # Modified prepared input must be rejected before starting a new simulation.
            (work / 'run_started.json').rename(work / 'old_run_started.json')
            (work / 'system.xml').write_text('modified')
            result = subprocess.run([sys.executable, str(work / 'run_md.py')], cwd=work, capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('modified', result.stderr)


if __name__ == '__main__':
    unittest.main()
