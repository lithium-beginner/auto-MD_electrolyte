"""Regression checks for actual numerical parameters and converted profiles."""
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from electrolyte.parameters import validate_bundle
from import_combat import topology, verify_energy
from electrolyte.recipe import split_smiles

ROOT=Path(__file__).resolve().parents[1]


class LibraryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.inventory=json.loads((ROOT/'library/inventory.json').read_text())

    def test_salt_stoichiometry_and_identity(self):
        for s in self.inventory['salts']:
            with self.subTest(salt=s['name']):
                fragments=split_smiles(s['smiles'],salt=True)
                self.assertEqual(sum(c for _,c in fragments),0)
                self.assertEqual(len(fragments),2)

    def test_all_bundles_integrity_charge_and_graph(self):
        for e in self.inventory['species']:
            for p in e['profiles']:
                with self.subTest(name=e['name'],profile=p['name']):
                    validate_bundle(ROOT/p['path'],e,p['family'])
                    self.assertFalse(p['validation']['physical_validation'])

    def test_chemical_mismatch_is_rejected(self):
        e=next(e for e in self.inventory['species'] if e['name']=='DME')
        with self.assertRaisesRegex(ValueError,'SMILES/forcefield'):
            validate_bundle(ROOT/e['profiles'][0]['path'],{'smiles':'CC','formal_charge':0})

    def test_forcefield_mixing_rejected(self):
        e=next(e for e in self.inventory['species'] if e['name']=='DME')
        p=next(p for p in e['profiles'] if p['family']=='OPLS-AA-ComBat')
        with self.assertRaisesRegex(ValueError,'forcefield'):
            validate_bundle(ROOT/p['path'],e,'GAFF2')

    def test_source_mutation_rejected(self):
        e=next(e for e in self.inventory['species'] if e['name']=='EC')
        with tempfile.TemporaryDirectory() as tmp:
            dst=Path(tmp)/'bundle';shutil.copytree(ROOT/e['profiles'][0]['path'],dst)
            with (dst/'molecule.itp').open('a') as f:f.write('; modified')
            with self.assertRaisesRegex(ValueError,'hash mismatch'):
                validate_bundle(dst,e,'GAFF2')

    def test_opls_energy_equivalence_reproducible(self):
        for name in ('MA','DOL','DME','TFSI'):
            e=next(e for e in self.inventory['species'] if e['name']==name)
            p=next(p for p in e['profiles'] if p['family']=='OPLS-AA-ComBat')
            source=ROOT/p['path']
            with tempfile.TemporaryDirectory() as tmp:
                out=Path(tmp)/'bundle';shutil.copytree(source,out)
                data=json.loads((out/'source_parameters.json').read_text())
                mol,bonds,angles,torsions,pairs,distances=topology(out/'molecule.pdb',e['smiles'])
                verify_energy(data,mol,bonds,angles,torsions,data.get('Improper Topologies') or [],distances,out)


if __name__=='__main__':unittest.main()
