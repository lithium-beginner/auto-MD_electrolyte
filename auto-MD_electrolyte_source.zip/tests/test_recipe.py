import copy
import json
from pathlib import Path
import unittest
from electrolyte.recipe import allocate, build_manifest, validate, split_smiles

EXAMPLE = Path(__file__).resolve().parents[1] / 'examples/ec_emc_lipf6.json'


class RecipeTests(unittest.TestCase):
    def setUp(self):
        self.r = json.loads(EXAMPLE.read_text())

    def test_mass_to_counts_and_charge(self):
        m = build_manifest(self.r)
        self.assertEqual(sum(x['formula_units'] for x in m['components']), 1000)
        self.assertEqual(sum(x['count'] * x['formal_charge'] for x in m['species']), 0)
        salt_count = m['components'][-1]['formula_units']
        self.assertEqual(m['particle_molecule_count'], 1000 + salt_count)
        self.assertEqual([x['formula_units'] for x in m['components']], [352, 546, 102])

    def test_multivalent_stoichiometry(self):
        self.r['salts'][0].update(smiles='[Mg+2].[Cl-].[Cl-]', molar_mass=95.21)
        m = build_manifest(self.r)
        counts = {s['formal_charge']: s['count'] for s in m['species'] if s['formal_charge']}
        self.assertEqual(counts[-1], 2 * counts[2])

    def test_formal_charge_not_text_sign(self):
        parts = split_smiles('C[N+](C)(C)CC(=O)[O-]')
        self.assertEqual(parts[0][1], 0)

    def test_uncharged_salt_rejected(self):
        with self.assertRaises(ValueError):
            split_smiles('Cl.[Li+]', salt=True)

    def test_rounding(self):
        self.assertEqual(allocate([1, 1, 1], 5), [2, 2, 1])

    def test_invalid_units_nan_purity_and_traversal(self):
        for mutation in ('unit', 'nan', 'purity', 'name'):
            r = copy.deepcopy(self.r)
            if mutation == 'unit': r['simulation']['units']['pressure'] = 'Pa'
            if mutation == 'nan': r['solvents'][0]['mass_fraction'] = float('nan')
            if mutation == 'purity': r['solvents'][0]['purity'] = 0.99
            if mutation == 'name': r['recipe_name'] = '../bad'
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                validate(r)

    def test_impurity_opt_in_and_trace_preservation(self):
        self.r['purity_policy'] = 'active_renormalize'
        self.r['solvents'][0]['purity'] = .99
        self.assertTrue(build_manifest(self.r)['warnings'])
        self.r['simulation']['total_molecules'] = 2
        with self.assertRaises(ValueError):
            build_manifest(self.r)


if __name__ == '__main__':
    unittest.main()
