import unittest
import numpy as np
from electrolyte.transport import unwrap_com, einstein_curves, fit_slope, viscosity, KB


class TransportTests(unittest.TestCase):
    def test_periodic_crossing(self):
        p = np.array([[[9., 0, 0]], [[1., 0, 0]], [[3., 0, 0]]])
        result = unwrap_com(p, np.array([10., 10., 10.]))
        np.testing.assert_allclose(result[:, 0, 0], [9, 11, 13])

    def test_collective_cancellation(self):
        p = np.zeros((20, 2, 3))
        p[:, :, 0] = np.arange(20)[:, None]
        t, msd, coll, origins = einstein_curves(p, [1, -1], 1)
        np.testing.assert_allclose(coll, 0)
        np.testing.assert_allclose(msd[0], 1e-20)
        self.assertEqual(origins[0], 19)

    def test_slope_and_diffusion_units(self):
        t = np.arange(1, 101) * 1e-12
        slope, r2 = fit_slope(t, 6 * 1e-9 * t, [.2, .8])
        self.assertAlmostEqual(slope / 6 / 1e-9, 1)
        self.assertAlmostEqual(r2, 1)

    def test_green_kubo_units(self):
        p = np.tile([1., -1.], 10)[:, None] * np.ones((1, 3))
        time, acf, eta = viscosity(p, 1, 10, 300)
        self.assertAlmostEqual(acf[0], 1e10)
        self.assertEqual(eta[0], 0)
        self.assertAlmostEqual(eta[1], (acf[1] + acf[0]) / 2 * 1e-12 * 10e-27 / (KB * 300))


if __name__ == '__main__':
    unittest.main()
