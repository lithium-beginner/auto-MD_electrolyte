# 本次验证范围

2026-10-08，macOS arm64，Python 3.12.14。依赖版本见 tested_versions.json。

运行命令（项目目录）：

```bash
PATH="$PWD/.venv312/bin:$PATH" PYTHONDONTWRITEBYTECODE=1 .venv312/bin/python -m unittest discover -s tests -v
```

结果：12 tests，全部通过。

验证覆盖：字段/单位/非有限数/质量分数/纯度政策；确定性取整和质量到分子计数；多价盐电荷守恒；形式电荷识别；周期质心展开；离子共同平移的集体电荷位移抵消；扩散及 Green–Kubo 单位转换；Packmol → .top/.itp/.atp → OpenMM 最小化/NVT/NPT/NVT → RDF/溶剂化/电导率分析；已准备输入修改检测。

端到端测试是 Ar + LiCl 的小型玩具体系，使用明确标注的任意 LJ 参数，仅验证软件衔接，不能用作物理预测。结果在临时目录内，测试结束即清理。

真实 EC/EMC/LiPF6 示例已生成工作目录（workdir/EC_EMC_LiPF6），未运行真实生产 MD。输入计数为 352 EC、546 EMC、102 LiPF6 单元，拆分后 1102 个分子/离子；初始密度约 1.2203 g/cm³，盐浓度约 1.2046 mol/L。

尚未验证：AmberTools/ACPYPE 实际自动参数化执行、真实离子力场、CUDA、Linux conda 环境、真实电解液实验一致性、压力张量黏度、长时间输运收敛。自动参数化使用上游支持的 MDL .mol 输入接口；自动生成后的参数仍需科学审核。

当前本地可用环境：.venv312。系统 Python 3.9 不符合项目要求；初次尝试的 .venv 未完成依赖安装，请使用 .venv312 或 README 中的 conda 环境。

## v0.2 参数库验证

新增 44 个组分身份、38 个有数值参数的组分、52 个参数包，支持 6 种完整锂盐。AmberTools 26.0/ACPYPE 2023.10.27 的实际 GAFF2/AM1-BCC 参数化已执行；原 v0.1 中“自动参数化尚未实际验证”的限制在工具运行层面已解除，化学适用性仍需验证。

18 项回归测试全部通过；52 个包通过显式 SMILES/PDB/ITP 连接、电荷、质量与来源文件哈希检查。14 个 ComBat OPLS 条目通过三构型、四类能量的独立 LAMMPS 公式与 OpenMM 等价检查。

三套真实组分软件流程通过：GAFF2 EC/EMC/LiPF6、OPLS DOL/DME/LiTFSI、GAFF2 纯 DME。前两套生产段仅 0.2 ps，纯 DME 仅 0.05 ps。这些是软件检查，不能用于物性预测；未把任何组分或配方标为实验性质验证通过。

实际来源与迁移限制见 library/README.md。生成的 69 份物理验证配方尚未运行；参考点仍待核实原始实验来源。
